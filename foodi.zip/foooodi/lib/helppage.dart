import 'package:flutter/material.dart';

class HelpPage extends StatelessWidget {
  const HelpPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Help & Support"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Center(
        child: Text(
          'Better Call Nawaf!',
          style: TextStyle(
            fontSize: 48, // Large font size
            fontWeight: FontWeight.bold,
            color: Colors.blueAccent, // You can adjust the color if you prefer
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
