import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:foooodi/loginpage.dart';

void main() async{

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(

      options: FirebaseOptions(
          apiKey: "AIzaSyAxFp6W9XVrNp_QfHVb0Fx2lsVcwAEPYhs",
          appId: "1:180453841739:android:59cf9bacf00c34a5d926ce",
          messagingSenderId:  "180453841739",
          projectId: "nfoodi")
  );
  runApp(const MaterialApp(

    home: Home(),
  ));
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return LoginPage();

  }
}
