import 'package:flutter/material.dart';

class FoodDetailPage extends StatefulWidget {
  final String name;
  final String imagePath;
  final String price;

  const FoodDetailPage({
    super.key,
    required this.name,
    required this.imagePath,
    required this.price,
  });

  @override
  State<FoodDetailPage> createState() => _FoodDetailPageState();
}

class _FoodDetailPageState extends State<FoodDetailPage> {
  int quantity = 1;
  bool needsCutlery = false;
  final TextEditingController _specialRequestController = TextEditingController();

  String mealDescription =
      "This is a delicious and savory meal made with fresh ingredients. Enjoy our special blend of spices and a satisfying portion.";

  List<Map<String, String>> recommendations = [
    {"name": "Water", "image": "assets/water.jpeg", "price": "0.200"},
    {"name": "Orange Juice", "image": "assets/orange.jpeg", "price": "0.200"},
    {"name": "Broasted", "image": "assets/broasted.jpg", "price": "1.700"},
    {"name": "Vegetables", "image": "assets/vegetables.jpeg", "price": "2.000"},
  ];

  List<String> selectedRecommendationNames = [];

  double get totalPrice {
    double basePrice = double.tryParse(widget.price) ?? 0;
    double recommendationsTotal = selectedRecommendationNames.fold(
      0.0,
          (sum, name) {
        final item = recommendations.firstWhere((item) => item['name'] == name);
        return sum + (double.tryParse(item["price"]!) ?? 0);
      },
    );
    return (basePrice * quantity) + recommendationsTotal;
  }

  void toggleRecommendation(String name) {
    setState(() {
      if (selectedRecommendationNames.contains(name)) {
        selectedRecommendationNames.remove(name);
      } else {
        selectedRecommendationNames.add(name);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        backgroundColor: Colors.pink,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image and quantity selector
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Image.asset(widget.imagePath, width: 140, height: 140, fit: BoxFit.cover),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.remove),
                          onPressed: () => setState(() {
                            if (quantity > 1) quantity--;
                          }),
                        ),
                        Text(quantity.toString(), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                        IconButton(
                          icon: const Icon(Icons.add),
                          onPressed: () => setState(() => quantity++),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text("Price: ${widget.price} OMR", style: const TextStyle(fontSize: 16, color: Colors.pink, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text("Total: ${totalPrice.toStringAsFixed(3)} OMR", style: const TextStyle(fontSize: 16, color: Colors.pink, fontWeight: FontWeight.bold)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 24),

            const Text("Description", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            Text(mealDescription, style: const TextStyle(fontSize: 14, color: Colors.grey)),
            const SizedBox(height: 24),

            const Text("You might also like...", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            const SizedBox(height: 8),
            SizedBox(
              height: 130,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: recommendations.length,
                itemBuilder: (context, index) {
                  final item = recommendations[index];
                  final isSelected = selectedRecommendationNames.contains(item["name"]);
                  return GestureDetector(
                    onTap: () => toggleRecommendation(item["name"]!),
                    child: Container(
                      width: 100,
                      margin: const EdgeInsets.only(right: 16),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.orange[100] : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        boxShadow: [
                          BoxShadow(color: Colors.grey.withOpacity(0.2), blurRadius: 6, offset: const Offset(0, 4)),
                        ],
                      ),
                      child: Column(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(item["image"]!, width: 80, height: 60, fit: BoxFit.cover),
                          ),
                          const SizedBox(height: 8),
                          Text(item["name"]!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                          Text("${item["price"]} OMR", style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 24),
            const Divider(),

            const Text("Special Request", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SwitchListTile(
              title: const Text("Cutlery"),
              subtitle: const Text("Select if you need cutlery. Reduce waste by only choosing this option when necessary."),
              value: needsCutlery,
              onChanged: (val) => setState(() => needsCutlery = val),
              activeColor: Colors.pink,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _specialRequestController,
              maxLines: 3,
              decoration: InputDecoration(
                hintText: "Any special requests?",
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
            ),

            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("✅ Your order is ready!"),
                      backgroundColor: Colors.green,
                      behavior: SnackBarBehavior.floating,
                      duration: Duration(seconds: 2),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pink,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text("Checkout", style: TextStyle(fontSize: 16)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
