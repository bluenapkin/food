import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class InsertFood extends StatefulWidget {
  const InsertFood({super.key});

  @override
  State<InsertFood> createState() => _InsertFoodState();
}

class _InsertFoodState extends State<InsertFood> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  List<DocumentSnapshot> _dishes = [];
  String? _editingId;

  final CollectionReference _foodCollection =
  FirebaseFirestore.instance.collection('dishes');

  @override
  void initState() {
    super.initState();
    _fetchDishes();
  }

  Future<void> _fetchDishes() async {
    QuerySnapshot snapshot = await _foodCollection.get();
    setState(() {
      _dishes = snapshot.docs;
    });
  }

  Future<void> _submitFood() async {
    if (_formKey.currentState!.validate()) {
      final String name = _nameController.text.trim();
      final String price = _priceController.text.trim();
      final String description = _descriptionController.text.trim();

      if (_editingId == null) {
        // Add new dish
        await _foodCollection.add({
          'name': name,
          'price': price,
          'description': description,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Dish '$name' added successfully!")),
        );
      } else {
        // Update existing dish
        await _foodCollection.doc(_editingId).update({
          'name': name,
          'price': price,
          'description': description,
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Dish '$name' updated successfully!")),
        );
        _editingId = null;
      }

      _nameController.clear();
      _priceController.clear();
      _descriptionController.clear();
      _formKey.currentState!.reset();
      _fetchDishes();
    }
  }

  void _editDish(DocumentSnapshot dish) {
    _nameController.text = dish['name'];
    _priceController.text = dish['price'];
    _descriptionController.text = dish['description'];
    setState(() {
      _editingId = dish.id;
    });
  }

  Future<void> _deleteDish(String id, String name) async {
    // Show confirmation dialog
    bool? shouldDelete = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Dish'),
          content: Text('Are you sure you want to delete the dish "$name"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false), // Cancel
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true), // Confirm
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    // If user confirmed deletion, delete the dish
    if (shouldDelete == true) {
      await _foodCollection.doc(id).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Dish '$name' deleted.")),
      );
      _fetchDishes();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add New Dish'),
        backgroundColor: Colors.pinkAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Dish Name'),
                    validator: (value) => value!.isEmpty ? 'Enter dish name' : null,
                  ),
                  TextFormField(
                    controller: _priceController,
                    decoration: const InputDecoration(labelText: 'Price'),
                    keyboardType: TextInputType.number,
                    validator: (value) => value!.isEmpty ? 'Enter price' : null,
                  ),
                  TextFormField(
                    controller: _descriptionController,
                    decoration: const InputDecoration(labelText: 'Description'),
                    validator: (value) => value!.isEmpty ? 'Enter description' : null,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _submitFood,
                    icon: Icon(_editingId == null ? Icons.add : Icons.edit),
                    label: Text(_editingId == null ? 'Add Dish' : 'Update Dish'),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.pink),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            if (_dishes.isNotEmpty)
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Your Dishes:",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: _dishes.length,
                    itemBuilder: (context, index) {
                      final dish = _dishes[index];
                      return Card(
                        child: ListTile(
                          title: Text(dish['name']),
                          subtitle: Text(
                              "Price: \$${dish['price']} — ${dish['description']}"),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: const Icon(Icons.edit, color: Colors.blue),
                                onPressed: () => _editDish(dish),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete, color: Colors.red),
                                onPressed: () => _deleteDish(dish.id, dish['name']),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
