import 'package:flutter/material.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});

  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  final List<Map<String, String>> foodItems = [
    {'name': 'Cheese Burger', 'price': '25', 'description': 'Juicy beef patty with cheese'},
    {'name': 'Shawarma Plate', 'price': '20', 'description': 'Grilled chicken with garlic sauce'},
    {'name': 'Pizza Margherita', 'price': '30', 'description': 'Classic tomato and mozzarella'},
    {'name': 'Pasta Alfredo', 'price': '28', 'description': 'Creamy sauce with mushrooms'},
  ];

  final List<Map<String, String>> selectedItems = [];

  double get totalPrice {
    return selectedItems.fold(0, (sum, item) => sum + double.parse(item['price'] ?? '0'));
  }

  void toggleSelection(Map<String, String> item) {
    setState(() {
      if (selectedItems.contains(item)) {
        selectedItems.remove(item);
      } else {
        selectedItems.add(item);
      }
    });
  }

  void placeOrder() {
    if (selectedItems.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one item')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Order Summary'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ...selectedItems.map((item) => ListTile(
              title: Text(item['name'] ?? ''),
              trailing: Text('${item['price']} OMR'),
            )),
            const Divider(),
            Text('Total: ${totalPrice.toStringAsFixed(2)} OMR',
                style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Order placed successfully!')),
              );
              setState(() => selectedItems.clear());
            },
            child: const Text('Confirm'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        backgroundColor: Colors.deepOrange,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: placeOrder,
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: foodItems.length,
        itemBuilder: (context, index) {
          final item = foodItems[index];
          final isSelected = selectedItems.contains(item);
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: ListTile(
              leading: Icon(Icons.fastfood, color: isSelected ? Colors.green : Colors.deepOrange),
              title: Text(item['name'] ?? ''),
              subtitle: Text(item['description'] ?? ''),
              trailing: Text('${item['price']} OMR'),
              tileColor: isSelected ? Colors.orange[50] : null,
              onTap: () => toggleSelection(item),
            ),
          );
        },
      ),
      bottomNavigationBar: selectedItems.isNotEmpty
          ? BottomAppBar(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: ElevatedButton(
            onPressed: placeOrder,
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepOrange),
            child: Text('Place Order - ${totalPrice.toStringAsFixed(2)} OMR'),
          ),
        ),
      )
          : null,
    );
  }
}
