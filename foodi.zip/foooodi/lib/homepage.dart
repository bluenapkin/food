import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'insert_food.dart';
import 'menu_screen.dart';
import 'profile_screen.dart';
import 'food_detail_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: _buildBottomNavigationBar(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(),
              const SizedBox(height: 20),
              _buildSearchAndNotificationRow(),
              const SizedBox(height: 20),
              _buildSpecialDealBanner(),
              const SizedBox(height: 30),
              _buildSectionTitle("Popular Menu"),
              const SizedBox(height: 10),
              _buildFoodRow(context, "Zinger Burger", "assets/zinger.jpg", "2 OMR", "Roll Paratha", "assets/roll.jpg", "3 OMR"),
              const SizedBox(height: 20),
              _buildFoodRow(context, "Macarons", "assets/sweet.jpg", "2 OMR", "Cupcake", "assets/cupcake.jpg", "3 OMR"),
            ],
          ),
        ),
      ),
    );
  }

  // Bottom Navigation Bar
  Widget _buildBottomNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      selectedItemColor: Colors.pinkAccent,
      unselectedItemColor: Colors.grey.shade600,
      backgroundColor: Colors.white,
      elevation: 12,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.restaurant), label: 'Menu'),
        BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Cart'),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
      ],
      onTap: (index) {
        if (index == 1) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => MenuScreen()));
        } else if (index == 2) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const InsertFood()));
        } else if (index == 3) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen()));
        }
      },
    );
  }

  // Header with text
  Widget _buildHeader() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Text(
            "Find Your\nFavourite Food",
            style: GoogleFonts.poppins(
              fontSize: 26,
              fontWeight: FontWeight.w700,
              color: Colors.black87,
            ),
          ),
        ),
        Align(
          alignment: Alignment.centerRight,
          child: Padding(
            padding: const EdgeInsets.only(right: 20, top: 8),
            child: Text(
              "Foodi Restaurant",
              style: GoogleFonts.pacifico(
                fontSize: 30,
                color: Colors.pinkAccent,
              ),
            ),
          ),
        ),
      ],
    );
  }

  // Search and notification row
  Widget _buildSearchAndNotificationRow() {
    return Row(
      children: [
        Expanded(
          child: TextField(
            decoration: InputDecoration(
              hintText: "Search for Food",
              prefixIcon: const Icon(Icons.search, color: Colors.pinkAccent),
              filled: true,
              fillColor: Colors.grey.shade200,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Icon(Icons.notifications_none, color: Colors.pinkAccent),
        ),
      ],
    );
  }

  // Special Deal Banner
  Widget _buildSpecialDealBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.pink.shade300, Colors.pink.shade500],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Special Deal For\nThis Month",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                ),
                const SizedBox(height: 10),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pinkAccent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                  child: const Text("Buy Now", style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Image.asset('assets/logo.png', width: 80),
        ],
      ),
    );
  }

  // Section Title with View More button
  Widget _buildSectionTitle(String title) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        Text(
          "View More",
          style: TextStyle(fontSize: 14, color: Colors.pink.shade400),
        ),
      ],
    );
  }

  // Food row (can be reused for any row of food)
  Widget _buildFoodRow(BuildContext context, String name1, String imagePath1, String price1, String name2, String imagePath2, String price2) {
    return Row(
      children: [
        _buildFoodCard(name1, imagePath1, price1, context),
        const SizedBox(width: 12),
        _buildFoodCard(name2, imagePath2, price2, context),
      ],
    );
  }

  // Food card widget
  Widget _buildFoodCard(String name, String imagePath, String price, BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => FoodDetailPage(
                name: name,
                imagePath: imagePath,
                price: price,
              ),
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.2),
                blurRadius: 8,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(imagePath, height: 120, width: 120, fit: BoxFit.cover),
              ),
              const SizedBox(height: 10),
              Text(
                name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 5),
              Text(
                price,
                style: const TextStyle(color: Colors.pinkAccent, fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
