import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'helppage.dart'; // Make sure HelpPage is imported here

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  User? user;
  String fullName = "";
  String email = "";
  String role = "";
  String profileImage = "assets/profile.jpg";

  @override
  void initState() {
    super.initState();
    getUserData();
  }

  Future<void> getUserData() async {
    user = FirebaseAuth.instance.currentUser;

    if (user != null) {
      final snapshot = await FirebaseFirestore.instance
          .collection('user')
          .where('email', isEqualTo: user!.email)
          .limit(1)
          .get();

      if (snapshot.docs.isNotEmpty) {
        final data = snapshot.docs.first.data();
        setState(() {
          email = user!.email!;
          fullName = "${data['first name']} ${data['last name']}";
          role = data['role'] ?? '';
        });
      }
    }
  }

  // Function to fetch users (for admin)
  Widget buildUserList() {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('user').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const CircularProgressIndicator();
        }

        final docs = snapshot.data!.docs
            .where((doc) => doc['email'] != email) // exclude current user
            .toList();

        if (docs.isEmpty) return const Text("No other users to manage.");

        return Expanded(
          child: ListView.builder(
            itemCount: docs.length,
            itemBuilder: (context, index) {
              final doc = docs[index];
              final name = "${doc['first name']} ${doc['last name']}";
              final userEmail = doc['email'];

              return ListTile(
                leading: const Icon(Icons.person),
                title: Text(name),
                subtitle: Text(userEmail),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: const Text("Confirm Deletion"),
                        content: Text("Are you sure you want to delete user '$userEmail'?"),
                        actions: [
                          TextButton(
                            child: const Text("Cancel"),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                          TextButton(
                            child: const Text("Delete", style: TextStyle(color: Colors.red)),
                            onPressed: () {
                              Navigator.of(context).pop();
                              deleteUser(doc.id, userEmail); // You can define this function to delete a user
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              );
            },
          ),
        );
      },
    );
  }

  // Ensure the logout function is working properly
  Future<void> logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.pushReplacementNamed(context, '/login');  // Redirect to login page after logout
  }

  // Function to delete a user
  Future<void> deleteUser(String docId, String userEmail) async {
    await FirebaseFirestore.instance.collection('user').doc(docId).delete();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("User $userEmail deleted.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow[50],
      appBar: AppBar(
        title: const Text("Profile"),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 50,
              backgroundColor: Colors.purpleAccent,
              child: Icon(Icons.person, size: 50, color: Colors.white),
            ),
            const SizedBox(height: 12),
            Text(fullName, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(email, style: const TextStyle(color: Colors.grey)),

            const SizedBox(height: 30),

            // Admin-only section
            if (role == 'admin') ...[
              const Text("Manage Users", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 10),
              buildUserList(),  // Show the list of users for the admin
              const SizedBox(height: 20),
            ],

            // Help & Support (shown to all)
            profileItem(Icons.help_outline, "Help & Support", onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const HelpPage()),
              );
            }),

            const SizedBox(height: 20),

            // Logout (shown to all)
            profileItem(Icons.logout, "Logout", color: Colors.red, onTap: logout), // Logout action
          ],
        ),
      ),
    );
  }

  Widget profileItem(IconData icon, String title,
      {Color color = Colors.black, VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: TextStyle(color: color)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      onTap: onTap ?? () {},
    );
  }
}
